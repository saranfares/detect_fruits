# detect_fruits

This project is written in python using a Keras framework for YOLO-3 (you only look once). Yolo is able to do realtime object detection (although it might have lower accuracy than a traditional R-CNN).

To run the project, 
